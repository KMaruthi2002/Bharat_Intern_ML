# Bharat-Intern-ML-Task-1
A machine learning model for predicting house prices using Python,scikit-learn, and TensorFlow.
